public class ControladorDeLetrasJaDigitadas implements Cloneable {
    private String letrasJaDigitadas;

    public ControladorDeLetrasJaDigitadas() {
        this.letrasJaDigitadas = "";
    }

    public boolean isJaDigitada(char letra) {
        return this.letrasJaDigitadas.indexOf(letra) != -1;
    }

    public void registre(char letra) throws Exception {
        if (isJaDigitada(letra)) throw new Exception("Letra já foi digitada.");
        this.letrasJaDigitadas += letra;
    }

    public String toString() {
        return String.join(",", this.letrasJaDigitadas.split(""));
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ControladorDeLetrasJaDigitadas that = (ControladorDeLetrasJaDigitadas) obj;
        return letrasJaDigitadas.equals(that.letrasJaDigitadas);
    }

    public int hashCode() {
        return letrasJaDigitadas.hashCode();
    }

    public ControladorDeLetrasJaDigitadas(ControladorDeLetrasJaDigitadas c) throws Exception {
        this.letrasJaDigitadas = c.letrasJaDigitadas;
    }

    public Object clone() {
        try {
            return new ControladorDeLetrasJaDigitadas(this);
        } catch (Exception e) {
            return null;
        }
    }
}
