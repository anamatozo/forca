public class Palavra {
    private String texto;

    // Construtor que recebe o texto da palavra
    public Palavra(String texto) {
        this.texto = texto;
    }

    // Método para obter o texto da palavra
    public String getTexto() {
        return texto;
    }

    // Método para retornar o número de letras da palavra
    public int getTamanho() {
        return texto.length();
    }

    // Método que retorna a quantidade de vezes que a letra aparece na palavra
    public int getQuantidade(char letra) {
        int quantidade = 0;
        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == letra) {
                quantidade++;
            }
        }
        return quantidade;
    }

    // Método que retorna a posição da i-ésima ocorrência de uma letra
    // Retorna -1 se a ocorrência não for encontrada
    public int getPosicaoDaIezimaOcorrencia(int i, char letra) {
        int ocorrencia = 0;
        for (int pos = 0; pos < texto.length(); pos++) {
            if (texto.charAt(pos) == letra) {
                if (ocorrencia == i) {
                    return pos;
                }
                ocorrencia++;
            }
        }
        return -1; // Retorna -1 se não encontrar a i-ésima ocorrência
    }
}
