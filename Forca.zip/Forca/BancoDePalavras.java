public class BancoDePalavras {
    // Declarando o array de palavras como final para indicar que ele não será alterado
    private static final String[] palavras = {
            "JAVA",
            "CLASSE",
            "OBJETO",
            "INSTANCIA",
            "PUBLICO",
            "PRIVATIVO",
            "METODO",
            "CONSTRUTOR",
            "SETTER",
            "GETTER",
            "LUZ",
            "PRAZER"
    };

    // Método para obter uma palavra sorteada do banco de palavras
    public static Palavra getPalavraSorteada() {
        Palavra palavra = null;
        try {
            // Seleciona uma palavra aleatória do array e cria um objeto Palavra com ela
            String palavraSorteada = BancoDePalavras.palavras[(int)(Math.random() * BancoDePalavras.palavras.length)];
            palavra = new Palavra(palavraSorteada);
        } catch (Exception e) {
            e.printStackTrace(); // Mostra o erro caso ocorra algum problema
        }
        return palavra;
    }
}
