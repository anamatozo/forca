public class ControladorDeErros implements Cloneable {
    private int qtdMax, qtdErr = 0;

    public ControladorDeErros(int qtdMax) throws Exception {
        if (qtdMax <= 0) throw new Exception("Quantidade máxima inválida.");
        this.qtdMax = qtdMax;
    }

    public void registreUmErro() throws Exception {
        if (this.qtdErr >= this.qtdMax) throw new Exception("Máximo de erros atingido.");
        this.qtdErr++;
    }

    public boolean isAtingidoMaximoDeErros() {
        return this.qtdErr >= this.qtdMax;
    }

    public String toString() {
        return this.qtdErr + "/" + this.qtdMax;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ControladorDeErros that = (ControladorDeErros) obj;
        return qtdMax == that.qtdMax && qtdErr == that.qtdErr;
    }

    public int hashCode() {
        return java.util.Objects.hash(qtdMax, qtdErr);
    }

    public ControladorDeErros(ControladorDeErros c) throws Exception {
        this.qtdMax = c.qtdMax;
        this.qtdErr = c.qtdErr;
    }

    public Object clone() {
        try {
            return new ControladorDeErros(this);
        } catch (Exception e) {
            return null;
        }
    }
}
