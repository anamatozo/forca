public class Tracinhos implements Cloneable {
    private char texto[];

    public Tracinhos(int qtd) throws Exception {
        if (qtd <= 0) throw new Exception("Quantidade inválida.");
        this.texto = new char[qtd];
        for (int i = 0; i < qtd; i++) this.texto[i] = '_';
    }

    public void revele(int posicao, char letra) throws Exception {
        if (posicao < 0 || posicao >= this.texto.length) throw new Exception("Posição inválida.");
        this.texto[posicao] = letra;
    }

    public boolean isAindaComTracinhos() {
        for (char c : this.texto) {
            if (c == '_') return true;
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (char c : this.texto) sb.append(c).append(" ");
        return sb.toString().trim();
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Tracinhos tracinhos = (Tracinhos) obj;
        return java.util.Arrays.equals(this.texto, tracinhos.texto);
    }

    public int hashCode() {
        return java.util.Arrays.hashCode(this.texto);
    }

    public Tracinhos(Tracinhos t) throws Exception {
        this.texto = new char[t.texto.length];
        System.arraycopy(t.texto, 0, this.texto, 0, t.texto.length);
    }

    public Object clone() {
        try {
            return new Tracinhos(this);
        } catch (Exception e) {
            return null;
        }
    }
}
